export const environment = {
    apiUrl: 'https://localhost:7294/api'
};
