export const environment = {
    apiUrl: 'PENDIENTE'
};
