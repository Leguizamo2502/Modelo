export interface person{
    id:number;
    first_name: string,
    last_name: string,
    phone_number: string,
    active: boolean
}
export interface personCreate{
    id:number;
    first_name: string,
    last_name: string,
    phone_number: string,
    active: boolean
}