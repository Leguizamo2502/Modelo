export interface rol{
    id:number;
    name:string;
    description:string;
    active:boolean;
}

export interface rolCreate{
    // id:number;
    name:string;
    description:string;
    active:boolean;
}
