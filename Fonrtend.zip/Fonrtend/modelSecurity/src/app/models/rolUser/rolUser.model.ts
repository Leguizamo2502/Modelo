export interface rolUser{
    id: number,
    userName: string,
    rolName: string,
    rolid: number,
    userid: number
}

export interface rolUserCreate{
    // id: number,
    // userName: string,
    // rolName: string,
    rolid: number,
    userid: number
}