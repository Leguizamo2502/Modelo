export interface formModule{
    id: number,
    form_name: string,
    module_name: string,
    moduleid: number,
    formid: number
}

export interface formModuleCreate{
    // id: number,
    // form_name: string,
    // module_name: string,
    moduleid: number,
    formid: number
}