export interface permission{
    id:number;
    name:string;
    description:string;
    active:boolean;
}

export interface permissionCreate{
    id:number;
    name:string;
    description:string;
    active:boolean;
}