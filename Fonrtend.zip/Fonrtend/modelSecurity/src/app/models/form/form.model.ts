export interface form{
    id:number;
    name:string;
    description:string;
    active:boolean;
}

export interface formCreate{
    // id:number;
    name:string;
    description:string;
    active:boolean;
}