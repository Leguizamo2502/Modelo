export interface user{
    id: 0,
    user_name: string,
    email: string,
    name_Person: string,
    active: boolean,
    person_id: 0
}
export interface userCreate{
    // id: 0,
    user_name: string,
    email: string,
    name_Person: string,
    active: boolean,
    person_id: 0
}